# ResumeIQ Backend - FastAPI Service

The backend service for **ResumeIQ** is built with FastAPI, PyMuPDF, and Python NLP heuristics. It parses PDF resumes, calculates 100-point ATS scores, detects skill taxonomy, performs Job Description match analysis, and integrates optional AI summary & interview question generation via Google Gemini.

## Setup Instructions

1. **Navigate to the backend directory**:
   ```bash
   cd backend
   ```

2. **Create a virtual environment (optional but recommended)**:
   ```bash
   python -m venv venv
   # On Windows:
   venv\Scripts\activate
   # On macOS/Linux:
   source venv/bin/activate
   ```

3. **Install Dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

4. **Set Environment Variables (Optional)**:
   Create a `.env` file from `.env.example`:
   ```bash
   cp .env.example .env
   ```
   Add your `GEMINI_API_KEY` if you want AI-generated summaries and custom interview questions.

5. **Start the Development Server**:
   ```bash
   python main.py
   # or
   uvicorn main:app --reload --port 8000
   ```

6. **Interactive Swagger API Documentation**:
   Visit `http://localhost:8000/docs` to test endpoints interactively.
