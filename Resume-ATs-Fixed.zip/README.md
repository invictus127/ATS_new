# ResumeIQ – AI Resume Analyzer & ATS Score Calculator

**ResumeIQ** is a full-stack, production-ready web application designed to evaluate ATS compatibility, parse contact information & technical skill taxonomies, compare resumes against job descriptions, detect missing keywords, calculate a 100-point ATS score, and offer actionable suggestions with AI interview question prep.

---

## Tech Stack

- **Frontend**: React + TypeScript + Tailwind CSS (Glassmorphism Dark Mode) + Lucide Icons + Vite
- **Backend**: FastAPI (Python) + PyMuPDF (`fitz`) + Pydantic + Uvicorn
- **AI Integration**: Google Gemini API (`google-genai`) with local rule-based fallback
- **Deployment Ready**: Vercel (Frontend) + Render (Backend)

---

## Key Features

1. 📤 **Drag-and-Drop PDF Upload**: Live drag hover effect, file size validation (max 5MB), metadata preview, and raw text paste option.
2. 🎯 **100-Point ATS Scoring Engine**: Evaluates 7 core pillars: Contact Info (15%), Skills Section (25%), Work Experience (20%), Education (10%), Projects (15%), Action Verbs (10%), Formatting (5%).
3. ⚡ **Skill Taxonomy Detector**: Automatically categorizes detected skills into:
   - Programming (Python, JavaScript, Java, C++, SQL, etc.)
   - Frameworks (React, FastAPI, Express, Next.js, Redux, etc.)
   - Databases (PostgreSQL, MongoDB, Redis, etc.)
   - Cloud & DevOps (AWS, Docker, Linux, CI/CD, etc.)
   - Tools (Git, Postman, Vite, VS Code, etc.)
   - Soft Skills (Leadership, Agile, Teamwork, etc.)
4. 🔍 **Job Description Keyword Matcher**: Paste a job description to see:
   - Keyword Match Percentage (e.g. 82%)
   - Missing Skills (e.g. `✗ Docker`, `✗ Kubernetes`, `✗ Redis`)
   - Matched Skills (e.g. `✓ Python`, `✓ React`, `✓ Git`)
5. 💡 **Actionable Suggestions**: Clear, prioritized recommendations to optimize your resume.
6. 📊 **Resume Statistics**: Word count, estimated reading time, section counts, project count, link count, and action verb ratio.
7. 🤖 **Bonus AI Features**:
   - Executive AI Professional Summary
   - Tailored Technical & Behavioral Interview Questions
   - Resume Bullet Point Optimizer (Original vs Quantifiable ATS Rewrites)
8. 📄 **Export Reports**: Download analysis as a PDF report or JSON file.

---

## Folder Structure

```
resume-analyzer/
├── backend/
│   ├── main.py                     # FastAPI entry point & CORS
│   ├── requirements.txt            # Python dependencies
│   ├── .env.example                # Environment variables template
│   ├── api/
│   │   └── routes.py               # Upload & text analyze endpoints
│   ├── models/
│   │   └── schemas.py              # Pydantic schemas
│   ├── parser/
│   │   └── pdf_parser.py           # PyMuPDF text & link parser
│   └── analyzer/
│       ├── skills_db.py            # 200+ skill taxonomy database
│       ├── ats_scorer.py           # 100-point ATS calculation engine
│       ├── jd_matcher.py           # JD match percentage & skill gap analyzer
│       └── ai_generator.py         # Gemini API bridge with rule-based fallback
└── frontend/
    ├── package.json                # Dependencies
    ├── vite.config.ts              # Vite config & API proxy
    ├── tailwind.config.js          # Glassmorphic theme & neon colors
    ├── index.html
    └── src/
        ├── index.css               # Custom glassmorphism CSS & radial glow
        ├── App.tsx                 # Dashboard container & state
        ├── main.tsx
        ├── types/                  # TypeScript interfaces
        ├── utils/                  # Sample data & report export tools
        └── components/             # Modular dashboard UI widgets
            ├── Header.tsx
            ├── FileUpload.tsx
            ├── JobDescriptionInput.tsx
            ├── AtsScoreCard.tsx
            ├── OverviewCards.tsx
            ├── SkillsBreakdown.tsx
            ├── SkillGapCard.tsx
            ├── SuggestionsCard.tsx
            ├── ResumeStats.tsx
            ├── ExtractedInfoCard.tsx
            ├── AiInsightsCard.tsx
            └── Footer.tsx
```

---

## How to Run the Project

### 1. Running Backend (FastAPI)
```bash
cd backend
pip install -r requirements.txt
python main.py
```
> Server will start at: `http://localhost:8000` (Swagger docs available at `http://localhost:8000/docs`).

### 2. Running Frontend (React + Vite)
```bash
cd frontend
npm install
npm run dev
```
> App will open at: `http://localhost:3000`.

---

## Resume Bullet Point (For your CV / Portfolio)

> Developed an AI-powered Resume Analyzer using React, TypeScript, Tailwind CSS, FastAPI, and PyMuPDF to evaluate ATS compatibility, extract candidate skills, compare resumes against job descriptions, calculate keyword match percentages, and generate actionable improvement suggestions.
