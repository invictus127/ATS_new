import fitz  # PyMuPDF
import re
from typing import Tuple, List, Dict
from models.schemas import ContactInfo

def extract_text_from_pdf_bytes(pdf_bytes: bytes) -> str:
    """Extract raw text from PDF file content bytes using PyMuPDF."""
    text = ""
    try:
        doc = fitz.open(stream=pdf_bytes, filetype="pdf")
        for page in doc:
            text += page.get_text("text") + "\n"
        doc.close()
    except Exception as e:
        print(f"Error reading PDF bytes: {e}")
        text = pdf_bytes.decode("utf-8", errors="ignore")
    return text.strip()

def parse_contact_info(text: str) -> ContactInfo:
    """Extract email, phone, links, and name from raw resume text."""
    contact = ContactInfo()
    
    # Email regex
    email_pattern = r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}'
    emails = re.findall(email_pattern, text)
    if emails:
        contact.email = emails[0]
        
    # Phone regex (supports international formats)
    phone_pattern = r'(\+?\d{1,3}[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}'
    phones = re.findall(phone_pattern, text)
    full_phones = re.findall(r'(\+?\d{1,3}[\s-]?)?\(?\d{3}\)?[\s-]?\d{3}[\s-]?\d{4}', text)
    if full_phones:
        p = full_phones[0]
        contact.phone = "".join(p) if isinstance(p, tuple) else p
    elif phones:
        p = phones[0]
        contact.phone = "".join(p) if isinstance(p, tuple) else p

    # LinkedIn regex
    linkedin_pattern = r'(https?://)?(www\.)?linkedin\.com/in/[a-zA-Z0-9_-]+'
    linkedin_matches = re.findall(linkedin_pattern, text, re.IGNORECASE)
    full_linkedin = re.findall(r'linkedin\.com/in/[a-zA-Z0-9_-]+', text, re.IGNORECASE)
    if full_linkedin:
        contact.linkedin = f"https://www.{full_linkedin[0]}"

    # GitHub regex
    github_pattern = r'github\.com/[a-zA-Z0-9_-]+'
    github_matches = re.findall(github_pattern, text, re.IGNORECASE)
    if github_matches:
        contact.github = f"https://{github_matches[0]}"

    # Portfolio / Link regex
    portfolio_pattern = r'(https?://[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}(?:/[^\s]*)?)'
    all_links = re.findall(portfolio_pattern, text)
    for link in all_links:
        if "linkedin" not in link and "github" not in link:
            contact.portfolio = link
            break

    # Name heuristic (first 3 non-empty lines that don't contain contact info)
    lines = [line.strip() for line in text.split('\n') if line.strip()]
    for line in lines[:5]:
        if not re.search(r'@|phone|\+?\d|linkedin|github|resume|cv', line, re.IGNORECASE):
            if len(line.split()) <= 4 and len(line) < 40:
                contact.name = line
                break
                
    if not contact.name and lines:
        contact.name = lines[0]

    return contact

def extract_sections(text: str) -> Dict[str, List[str]]:
    """Segment resume text into main section blocks."""
    sections = {
        "education": [],
        "experience": [],
        "projects": [],
        "certifications": [],
        "summary": []
    }
    
    current_section = "summary"
    lines = text.split('\n')
    
    section_headers = {
        "education": r'\b(education|academic|qualification|university|college)\b',
        "experience": r'\b(experience|work history|employment|career|work experience)\b',
        "projects": r'\b(projects|key projects|personal projects|technical projects)\b',
        "certifications": r'\b(certifications|certificates|licenses|achievements|courses)\b'
    }
    
    for line in lines:
        clean_line = line.strip()
        if not clean_line:
            continue
            
        # Check if line is a section header
        header_matched = False
        for sec_name, pattern in section_headers.items():
            if re.search(pattern, clean_line, re.IGNORECASE) and len(clean_line.split()) <= 4:
                current_section = sec_name
                header_matched = True
                break
                
        if not header_matched:
            sections[current_section].append(clean_line)
            
    return sections
